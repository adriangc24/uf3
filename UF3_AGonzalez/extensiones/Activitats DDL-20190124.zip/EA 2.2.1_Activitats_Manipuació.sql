/*Exercici 1* - Disponsem de la següent base de dades per gestionar la informació dels pubs d'una determinada província:*/

create table localitat (
	cod_localitat number(5),
	nom varchar(20) not null,
		constraint pk_clocalitat primary key(cod_localitat));

create table pub (
	cod_pub varchar2(5),
	nom varchar2(20) not null,
	llicencia varchar2(20) not null,
	domicili varchar2(60),
	data_apertura date not null,
	horari varchar2(5) not null,
	cod_localitat number(5) not null,
		constraint pk_cpub primary key (cod_pub),
		constraint fk_clocalitat foreign key (cod_localitat) references localitat (cod_localitat),
		constraint chk_horari check (horari in ('HOR1', 'HOR2','HOR3')));

create table titular (
	dni_titular varchar2(10),
	nom varchar2(20) not null,
	domicili varchar2(60),
	cod_pub varchar2(5) not null,
		constraint pk_dnit primary key (dni_titular),
		constraint fk_cpub foreign key (cod_pub) references pub (cod_pub));

create table empleat (
	dni_empleat varchar2(10),
	nom varchar2(20) not null,
	domicili varchar2(60),
		constraint pk_dnie primary key (dni_empleat));

create table existencies (
	cod_article varchar2(5),
	nom varchar2(30) not null,
	quantitat number (7,2) not null, 
	preu number (7,2) not null,
	cod_pub varchar2(5) not null,
		constraint pk_cart primary key (cod_article),
		constraint fk_exis_cpub foreign key (cod_pub) references pub (cod_pub),
		constraint chk_preu check (preu <> 0));

create table pub_empleat (
	cod_pub varchar2(5),
	dni_empleat varchar2(10),
	funcio varchar2(10) not null,
		constraint fk_cpub_empleat foreign key cod_pub references pub(cod_pub),
		constraint fk_dni_pempleat foreign key dni_empleat references empleat(dni_empleat),
		constraint chk_pub_empleat check (funcio in ('Cambrer', 'Seguretat', 'Neteja')));
		
/*Exercici 2.	La següent base de dades està pensada per emmagatzemar la informació necessària per gestionar la venda automàtica d’entrades per diferents espectacles des de múltiples punts de venda, com pot ser oficines, terminals de tipus ServiCaixa o les mateixes taquilles de teatres o altres recintes.*/

•	espectacles (cod_espectacle, nom, tipus, data_inicial, data_final, interpret, cod_recinte)
•	preus_espectacles (cod_espectacle, cod_recinte, zona, preu)
•	recintes (cod_recinte, nom, adreça, ciutat, telefon, horari)
•	zona_recinte (cod_recinte, zona, capacitat)
•	seient (cod_recinte, zona, fila, num)
•	representacio (cod_espectacle, data, hora)
•	entrada (cod_espectacle, data, hora, cod_recinte, fila, num, zona, dni_client)
•	espectador (dni_client, nom, adreça, telefon, ciutat, ntargeta)

create table recintes (
	cod_recinte varchar2(6), 
	nom varchar2(30), 
	adreça varchar2(40), 
	ciutat varchar2(12), 
	telefon number(9), 
	horari varchar2(8),  -- Exemple 12:00 PM
		constraint pk_recintes primary key (cod_recinte));

create table zona_recinte (
	cod_recinte varchar2(6), 
	zona varchar2(6), 
	capacitat number (4),
		constraint fk_zona_rec_crect foreign key (cod_recinte) references recintes(cod_recinte));
		
create table seient (
	cod_recinte varchar2(6), 
	zona varchar2(10), 
	fila varchar2(2), 
	num number(3),
		constraint fk_seint_crect foreign key (cod_recinte) references recintes(cod_recinte));
		
create table espectador (
	dni_client varchar2(10), 
	nom varchar2(30), 
	adreça varchar2(30), 
	telefon number(9), 
	ciutat varchar2(12), 
	ntargeta number(16),
		constraint pk_dnic_espectador primary key (dni_client));
		
create table espectacles (
	cod_espectacle varchar2(6), 
	nom varchar2(6), 
	tipus varchar2(6), 
	data_inicial date, 
	data_final date, 
	interpret varchar2(6), 
	cod_recinte varchar2(6),
		constraint pk_espectacle primary key (cod_espectacle),
		constraint fk_cod_rec_espectacle foreign key (cod_recinte) references recintes (cod_recinte));

create table preus_espectacles (
	cod_espectacle varchar2(6), 
	cod_recinte varchar2(6), 
	zona varchar2(10), 
	preu number(6,2),
		constraint fk_cod_espec_preu_esp foreign key (cod_espectacle) references espectacles(cod_espectacle),
		constraint fk_cod_rec_esp foreign key (cod_recinte) references recintes(cod_recinte));

create table representacio (
	cod_espectacle varchar2(6),  
	data date, 
	hora  varchar2(8),  -- Exemple 12:00 PM
		constraint fk_cod_espec_represen foreign key (cod_espectacle) references espectacles(cod_espectacle));
		
create table entrada (
	cod_espectacle varchar2(6), 
	data date, 
	hora  varchar2(8),  -- Exemple 12:00 PM 
	cod_recinte varchar2(6),
	fila varchar2(2), 
	num number(3),
	zona varchar2(10), 
	dni_client varchar2(10),
		constraint fk_cod_espec_entrada foreign key (cod_espectacle) references espectacles(cod_espectacle),
		constraint fk_cod_rec_entrada foreign key (cod_recinte) references recintes(cod_recinte),
		constraint fk_dni_client_entrada foreign key (dni_client) references espectador (dni_client));	

/*Exercici 3.	Es desitja tenir una base de dades que emmagatzemi la informació dels empleats d’una empresa, els departaments en els que treballen i els estudis que disposen. Guardarem l’historial laboral i salarial de tots els empleats. Per això, disposem de les següents taules:*/

create table empleats (	
	dni	number(8),
	nom	varchar(10) not null,
	cognom1	varchar(15) not null,
	cognom2	varchar(15),
	adreça1	varchar(25),
	adreça2	varchar(20),
	ciutat	varchar(20),
	provincia	varchar(20),
	cod_postal	varchar(5),
	sexe	varchar(1),
	data_naixement	date,
		constraint pk_empleats_dni primary key (dni),
		constraint chk_sex_empleat check (sexe in ('H','D')));
		

create table universitat(	
	univ_cod number(5),
	nom_univ varchar(25) not null,
	ciutat varchar(20),
	municipi varchar(20),
	cod_postal varchar(5),
		constraint pk_univ_cod primary key (univ_cod));
	
create table treball(
	treball_cod	number(5),
	nom_treball	varchar(20) not null,
	salari_min	number(9,2) not null,
	salari_max	number(9,2) not null,
		constraint pk_treball primary key (treball_cod),
		constraint uq_nom_trebll unique (nom_treball));

create table departaments(
	dpto_cod	number(5),
	nom_dpto	varchar(30) not null,
	dpto_pare	number(5),
	presupost	number(9,3) not null,
	pres_actual	number(9,3),
		constraint pk_dpto_cod primary key (dpto_cod),
		constraint fk_depart_dpto_pare foreign key (dpto_pare) references departaments(dpto_cod),
		constraint uq_nom_dpto unique (nom_dpto));
	
create table estudis( 
	empleat_dni	number(8),
	univ_cod number(8),
	anys number(4),
	grau varchar(3),
	especialitat varchar(20),
		constraint pk_estudis primary key(empleat_dni, univ_cod, especialitat),
		constraint fk_estudis_empleat foreign key (empleat_dni) references empleats(dni),
		constraint fk_estudis_univ foreign key (univ_cod) references universitat(univ_cod));
	
create table historial_salarial(
	empleat_dni	number(8),
	salari	number(9,2) not null,
	data_inici	date,
	data_fi	date,
		constraint pk_hist_sal_empl primary key (empleat_dni, salari, data_inici),
		constraint fk_hist_empdni foreign key (empleat_dni) references empleats (dni));

create table historial_laboral	(
	empleat_dni	number(8),
	treball_cod	number(5),
	data_inici	date,
	data_fi	date,
	dpto_cod number(5),
	supervisor_dni	number(8),
		constraint pk_hist_lab_emp primary key (empleat_dni, treball_cod, data_inici),
		constraint fk_hist_lab_empleat foreign key (empleat_dni) references empleats(dni),
		constraint fk_hist_lab_supervisor foreign key (supervisor_dni) references empleats(dni),
		constraint fk_hist_lab_treball_cod foreign key (dpto_cod) references treball(treball_cod),
		constraint fk_hist_lab_dept_cod foreign key (dpto_cod) references departaments(dpto_cod));
		
	
